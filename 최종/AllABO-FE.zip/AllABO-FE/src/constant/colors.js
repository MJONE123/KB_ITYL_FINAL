const COLORS = {
  primaryColor : "#F4BF42",
  kbDarkGray : "#5F584E"
}

export default COLORS;