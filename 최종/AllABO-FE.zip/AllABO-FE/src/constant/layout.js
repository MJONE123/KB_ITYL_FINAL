const LAYOUT_VARIANTS = {
    default : "py-16 px-[20%]"
  }
  
export default LAYOUT_VARIANTS;
