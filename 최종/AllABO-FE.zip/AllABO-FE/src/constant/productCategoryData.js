const productCategoryData = [
  { id: 0, name: '카드', color: '#D7E9FA' },
  { id: 1, name: '예/적금', color: '#FAE6A2' },
  { id: 2, name: '대출', color: '#F8D8D8' },
  { id: 3, name: '보험', color: '#DBF2BB' },
];

export default productCategoryData;
