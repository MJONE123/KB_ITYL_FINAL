<template>
  <div class="h-screen">
    <StrategyForPrivate />
  </div>
</template>
<script setup>
import StrategyForPrivate from '../components/AssetPlanStrategy/StrategyForPrivate.vue';
</script>
