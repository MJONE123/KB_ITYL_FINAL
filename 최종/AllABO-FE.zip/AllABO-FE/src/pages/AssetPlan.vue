<template>
  <div class="h-screen">
    <AssetPlanNavigation />
  </div>
</template>
<script setup>
import AssetPlanNavigation from '../components/AssetPlan/AssetPlanNavigation.vue';
</script>
