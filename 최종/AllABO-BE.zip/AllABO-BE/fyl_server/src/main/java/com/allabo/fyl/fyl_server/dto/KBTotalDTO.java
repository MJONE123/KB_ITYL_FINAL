package com.allabo.fyl.fyl_server.dto;

public class KBTotalDTO {
    private int customerId;
    private int totalAccountBalance;
    private int totalCardAmount;
    private int totalInsurancePremium;
    private int totalRemainingBalance;
}

