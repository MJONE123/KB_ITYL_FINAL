package com.allabo.fyl.fyl_server.exception;

public class PhoneNumberMismatchException extends RuntimeException {
    public PhoneNumberMismatchException(String message) {
        super(message);
    }
}