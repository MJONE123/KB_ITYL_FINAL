package com.allabo.fyl.fyl_server.mapper;

public interface ChatMapper {
}
