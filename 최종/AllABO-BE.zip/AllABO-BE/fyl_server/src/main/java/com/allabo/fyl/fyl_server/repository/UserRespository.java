package com.allabo.fyl.fyl_server.repository;

public class UserRespository {
}
