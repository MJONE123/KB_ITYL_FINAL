package com.allabo.fyl.fyl_server;

public class AssetAnalysisApplication {
}
