package com.allabo.fyl.fyl_server.exception;

public class AddException extends Exception{
    public AddException(String message) {
        super(message);
    }

    public AddException() {
    }
}
