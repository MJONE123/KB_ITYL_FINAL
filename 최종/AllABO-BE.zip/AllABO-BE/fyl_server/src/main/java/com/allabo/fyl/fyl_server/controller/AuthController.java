package com.allabo.fyl.fyl_server.controller;

public class AuthController {
}
