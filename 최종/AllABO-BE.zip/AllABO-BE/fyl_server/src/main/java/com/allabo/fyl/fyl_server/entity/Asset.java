package com.allabo.fyl.fyl_server.entity;

public class Asset {
}
