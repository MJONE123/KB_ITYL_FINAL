---
name: Feature request
about: 기능 추가 이슈 템플릿
title: ''
labels: ''
assignees: ''

---

## 어떤 기능인가요?

> 추가하려는 기능에 대해 간결하게 설명해주세요

## 작업 상세 내용

- [ ] TODO
- [ ] TODO
- [ ] TODO

## 참고할만한 자료(선택)
